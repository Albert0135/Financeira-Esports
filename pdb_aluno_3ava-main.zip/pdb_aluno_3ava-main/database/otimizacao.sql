-- ============================================================
--  ARENA GAMER  –  otimizacao.sql (VERSÃO DO ALUNO)
--  AULA 5  –  EXPLAIN, ANALYZE e INDEX estratégico
-- ============================================================

USE arena_gamer;

-- ============================================================
-- 1. DIAGNÓSTICO INICIAL
-- ============================================================

EXPLAIN
SELECT s.id_sessao, cl.nome, co.numero, s.valor_total
FROM sessoes s
JOIN clientes cl
    ON s.id_cliente = cl.id_cliente
JOIN computadores co
    ON s.id_computador = co.id_computador
WHERE s.status = 'fechada'
ORDER BY s.valor_total DESC;

-- ============================================================
-- 2. CRIAÇÃO DOS ÍNDICES
-- ============================================================

-- Índice para filtro por status
CREATE INDEX idx_sessoes_status
ON sessoes(status);

-- Índice para JOIN com clientes
CREATE INDEX idx_sessoes_cliente
ON sessoes(id_cliente);

-- Índice para JOIN com computadores
CREATE INDEX idx_sessoes_computador
ON sessoes(id_computador);

-- Índice para busca por e-mail
-- (o UNIQUE já cria um índice automaticamente,
-- mas a atividade pede explicitamente)
CREATE INDEX idx_clientes_email
ON clientes(email);

-- ============================================================
-- 3. DIAGNÓSTICO APÓS OTIMIZAÇÃO
-- ============================================================

EXPLAIN
SELECT s.id_sessao, cl.nome, co.numero, s.valor_total
FROM sessoes s
JOIN clientes cl
    ON s.id_cliente = cl.id_cliente
JOIN computadores co
    ON s.id_computador = co.id_computador
WHERE s.status = 'fechada'
ORDER BY s.valor_total DESC;

-- ============================================================
-- 4. EXPLAIN FORMAT JSON
-- ============================================================

EXPLAIN FORMAT=JSON
SELECT
    cl.nome,
    COUNT(*) AS sessoes,
    SUM(s.valor_total) AS total
FROM clientes cl
JOIN sessoes s
    ON cl.id_cliente = s.id_cliente
WHERE s.status = 'fechada'
GROUP BY cl.id_cliente
HAVING total > 30
ORDER BY total DESC;

-- ============================================================
-- 5. SUBQUERY CORRELACIONADA
-- ============================================================

EXPLAIN
SELECT
    cl.nome,
    SUM(s.valor_total) AS total_gasto,
    (
        SELECT AVG(valor_total)
        FROM sessoes
        WHERE status = 'fechada'
    ) AS media_geral
FROM clientes cl
JOIN sessoes s
    ON cl.id_cliente = s.id_cliente
   AND s.status = 'fechada'
GROUP BY cl.id_cliente, cl.nome
HAVING total_gasto >
(
    SELECT AVG(valor_total)
    FROM sessoes
    WHERE status = 'fechada'
)
ORDER BY total_gasto DESC;

-- ============================================================
-- 6. LISTAR TODOS OS ÍNDICES
-- ============================================================

SELECT
    TABLE_NAME,
    INDEX_NAME,
    COLUMN_NAME,
    NON_UNIQUE
FROM INFORMATION_SCHEMA.STATISTICS
WHERE TABLE_SCHEMA = 'arena_gamer'
ORDER BY TABLE_NAME, INDEX_NAME;
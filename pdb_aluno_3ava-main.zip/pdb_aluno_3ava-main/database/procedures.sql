-- ============================================================
--  ARENA GAMER  –  procedures.sql (VERSÃO DO ALUNO)
--  AULAS 3 e 4  –  Functions, Stored Procedures, Triggers e Views
--
--  Execute APÓS schema.sql e seed.sql
-- ============================================================

USE arena_gamer;

DELIMITER //

-- ============================================================
-- FUNCTIONS
-- ============================================================

CREATE FUNCTION fn_duracao_minutos(
    p_inicio DATETIME,
    p_fim DATETIME
)
RETURNS INT
DETERMINISTIC
BEGIN
    RETURN TIMESTAMPDIFF(MINUTE, p_inicio, p_fim);
END //

CREATE FUNCTION fn_calcular_valor(
    p_inicio DATETIME,
    p_fim DATETIME,
    p_valor_hora DECIMAL(6,2)
)
RETURNS DECIMAL(8,2)
DETERMINISTIC
BEGIN
    DECLARE v_minutos INT;
    DECLARE v_valor DECIMAL(8,2);

    SET v_minutos = fn_duracao_minutos(p_inicio, p_fim);

    SET v_valor = ROUND((v_minutos / 60) * p_valor_hora, 2);

    RETURN v_valor;
END //

-- ============================================================
-- STORED PROCEDURE - ABRIR SESSÃO
-- ============================================================

CREATE PROCEDURE sp_abrir_sessao(
    IN p_id_cliente INT,
    IN p_id_computador INT
)
BEGIN

    DECLARE v_status VARCHAR(20);

    SELECT status
    INTO v_status
    FROM computadores
    WHERE id_computador = p_id_computador;

    IF v_status <> 'disponivel' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Computador não está disponível.';
    END IF;

    START TRANSACTION;

        INSERT INTO sessoes(
            id_cliente,
            id_computador
        )
        VALUES(
            p_id_cliente,
            p_id_computador
        );

        UPDATE computadores
        SET status = 'ocupado'
        WHERE id_computador = p_id_computador;

    COMMIT;

END //

-- ============================================================
-- STORED PROCEDURE - FECHAR SESSÃO
-- ============================================================

CREATE PROCEDURE sp_fechar_sessao(
    IN p_id_sessao INT
)
BEGIN

    DECLARE v_inicio DATETIME;
    DECLARE v_id_computador INT;
    DECLARE v_valor_hora DECIMAL(6,2);
    DECLARE v_valor_sessao DECIMAL(8,2);
    DECLARE v_valor_vendas DECIMAL(8,2);
    DECLARE v_valor_total DECIMAL(8,2);

    SELECT
        s.inicio,
        s.id_computador,
        c.valor_hora
    INTO
        v_inicio,
        v_id_computador,
        v_valor_hora
    FROM sessoes s
    INNER JOIN computadores c
        ON c.id_computador = s.id_computador
    WHERE s.id_sessao = p_id_sessao
      AND s.status = 'aberta';

    IF v_inicio IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT =
        'Sessão não encontrada ou já encerrada.';
    END IF;

    SET v_valor_sessao =
        fn_calcular_valor(
            v_inicio,
            NOW(),
            v_valor_hora
        );

    SELECT COALESCE(
        SUM(quantidade * preco_unitario),
        0
    )
    INTO v_valor_vendas
    FROM vendas
    WHERE id_sessao = p_id_sessao;

    SET v_valor_total =
        v_valor_sessao + v_valor_vendas;

    START TRANSACTION;

        UPDATE sessoes
        SET
            fim = NOW(),
            valor_total = v_valor_total,
            status = 'fechada'
        WHERE id_sessao = p_id_sessao;

        UPDATE computadores
        SET status = 'disponivel'
        WHERE id_computador = v_id_computador;

    COMMIT;

END //

-- ============================================================
-- TRIGGER AUDITORIA
-- ============================================================

CREATE TRIGGER trg_auditoria_sessao
AFTER UPDATE ON sessoes
FOR EACH ROW
BEGIN

    IF OLD.status = 'aberta'
       AND NEW.status = 'fechada' THEN

        INSERT INTO auditoria_caixa(
            tipo,
            valor,
            descricao,
            id_sessao
        )
        VALUES(
            'entrada',
            NEW.valor_total,
            CONCAT(
                'Sessão #',
                NEW.id_sessao,
                ' encerrada - cliente ',
                NEW.id_cliente
            ),
            NEW.id_sessao
        );

    END IF;

END //

-- ============================================================
-- TRIGGER VALIDAÇÃO DE ESTOQUE
-- ============================================================

CREATE TRIGGER trg_valida_estoque
BEFORE INSERT ON vendas
FOR EACH ROW
BEGIN

    DECLARE v_estoque INT;

    SELECT estoque
    INTO v_estoque
    FROM produtos
    WHERE id_produto = NEW.id_produto;

    IF v_estoque < NEW.quantidade THEN

        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT =
        'Estoque insuficiente para a venda.';

    END IF;

END //

-- ============================================================
-- TRIGGER ATUALIZA ESTOQUE
-- ============================================================

CREATE TRIGGER trg_atualiza_estoque
AFTER INSERT ON vendas
FOR EACH ROW
BEGIN

    UPDATE produtos
    SET estoque = estoque - NEW.quantidade
    WHERE id_produto = NEW.id_produto;

END //

DELIMITER ;

-- ============================================================
-- VIEW SESSÕES ATIVAS
-- ============================================================

CREATE OR REPLACE VIEW vw_sessoes_ativas AS
SELECT
    s.id_sessao,
    c.nome AS cliente,
    cp.numero AS computador,
    cp.descricao AS descricao_computador,
    s.inicio,

    TIMESTAMPDIFF(
        MINUTE,
        s.inicio,
        NOW()
    ) AS minutos_em_uso,

    ROUND(
        (
            TIMESTAMPDIFF(
                MINUTE,
                s.inicio,
                NOW()
            ) / 60
        ) * cp.valor_hora,
        2
    ) AS valor_parcial

FROM sessoes s
INNER JOIN clientes c
    ON c.id_cliente = s.id_cliente
INNER JOIN computadores cp
    ON cp.id_computador = s.id_computador
WHERE s.status = 'aberta';

-- ============================================================
-- VIEW RANKING CLIENTES
-- ============================================================

CREATE OR REPLACE VIEW vw_ranking_clientes AS
SELECT
    c.id_cliente,
    c.nome,

    COUNT(s.id_sessao) AS total_sessoes,

    COALESCE(
        SUM(s.valor_total),
        0
    ) AS total_gasto,

    COALESCE(
        AVG(s.valor_total),
        0
    ) AS gasto_medio

FROM clientes c
LEFT JOIN sessoes s
    ON c.id_cliente = s.id_cliente
   AND s.status = 'fechada'

GROUP BY
    c.id_cliente,
    c.nome

ORDER BY total_gasto DESC;

-- ============================================================
-- VIEW PRODUTOS MAIS VENDIDOS
-- ============================================================

CREATE OR REPLACE VIEW vw_produtos_mais_vendidos AS
SELECT
    p.nome,
    p.categoria,

    COALESCE(
        SUM(v.quantidade),
        0
    ) AS total_vendido,

    COALESCE(
        SUM(
            v.quantidade *
            v.preco_unitario
        ),
        0
    ) AS receita_total

FROM produtos p
LEFT JOIN vendas v
    ON p.id_produto = v.id_produto

GROUP BY
    p.id_produto,
    p.nome,
    p.categoria

ORDER BY total_vendido DESC;
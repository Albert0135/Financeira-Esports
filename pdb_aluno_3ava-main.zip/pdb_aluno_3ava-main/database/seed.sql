-- ============================================================
--  ARENA GAMER  –  seed.sql  (VERSÃO DO ALUNO)
--  AULA 1  –  Dados iniciais para desenvolvimento e testes
--
--  Execute APÓS schema.sql.
--  O sistema precisa de dados para funcionar corretamente.
-- ============================================================

USE arena_gamer;

-- ============================================================
-- COMPUTADORES
-- ============================================================

INSERT INTO computadores (numero, descricao, valor_hora) VALUES
(1, 'PC Gamer RTX 4070', 10.00),
(2, 'PC Gamer RTX 4060', 9.00),
(3, 'PC Gamer RTX 3060', 8.00),
(4, 'PC Standard GTX 1660', 7.00),
(5, 'PC Standard GTX 1650', 6.50),
(6, 'PC Office Ryzen 5', 5.00);

-- ============================================================
-- CLIENTES
-- ============================================================

INSERT INTO clientes (nome, email, telefone, saldo_creditos) VALUES
('Joao Silva', 'joao@email.com', '85999990001', 50.00),
('Maria Souza', 'maria@email.com', '85999990002', 20.00),
('Pedro Santos', 'pedro@email.com', '85999990003', 0.00),
('Ana Lima', 'ana@email.com', '85999990004', 15.00),
('Carlos Oliveira', 'carlos@email.com', '85999990005', 100.00);

-- ============================================================
-- PRODUTOS
-- ============================================================

INSERT INTO produtos (nome, categoria, preco, estoque) VALUES
('Coca-Cola Lata', 'Bebidas', 6.00, 100),
('Guarana Antarctica', 'Bebidas', 5.50, 80),
('Agua Mineral', 'Bebidas', 3.00, 120),
('Doritos', 'Snacks', 8.00, 50),
('Fandangos', 'Snacks', 6.00, 40),
('Hamburguer Artesanal', 'Lanches', 18.00, 30),
('Misto Quente', 'Lanches', 10.00, 35),
('Mousepad Gamer', 'Acessorios', 35.00, 15),
('Headset Gamer', 'Acessorios', 120.00, 10);

-- ============================================================
-- SESSÕES HISTÓRICAS
-- ============================================================

INSERT INTO sessoes
(id_cliente, id_computador, inicio, fim, valor_total, status)
VALUES
(1, 1, '2026-04-20 14:00:00', '2026-04-20 16:00:00', 20.00, 'fechada'),
(2, 2, '2026-04-21 10:00:00', '2026-04-21 12:30:00', 22.50, 'fechada'),
(3, 3, '2026-04-22 15:00:00', '2026-04-22 17:00:00', 16.00, 'fechada'),
(4, 4, '2026-04-23 09:00:00', '2026-04-23 11:00:00', 14.00, 'fechada'),
(5, 5, '2026-04-24 18:00:00', '2026-04-24 20:00:00', 13.00, 'fechada'),
(1, 6, '2026-04-25 13:00:00', '2026-04-25 16:00:00', 15.00, 'fechada');

-- ============================================================
-- VENDAS
-- ============================================================

INSERT INTO vendas
(id_sessao, id_produto, quantidade, valor_unitario)
VALUES
(1, 1, 2, 6.00),
(1, 4, 1, 8.00),

(2, 2, 2, 5.50),
(2, 6, 1, 18.00),

(3, 3, 1, 3.00),
(3, 5, 2, 6.00),

(4, 1, 1, 6.00),
(4, 7, 1, 10.00),

(5, 4, 2, 8.00),

(6, 8, 1, 35.00);

-- ============================================================
-- AUDITORIA DE CAIXA
-- ============================================================

INSERT INTO auditoria_caixa
(tipo, valor, descricao, data_movimento)
VALUES
('entrada', 20.00, 'Sessao #1 encerrada', NOW()),
('entrada', 22.50, 'Sessao #2 encerrada', NOW()),
('entrada', 16.00, 'Sessao #3 encerrada', NOW()),
('entrada', 14.00, 'Sessao #4 encerrada', NOW()),
('entrada', 13.00, 'Sessao #5 encerrada', NOW()),
('entrada', 15.00, 'Sessao #6 encerrada', NOW()),
('saida', 50.00, 'Reposicao de estoque', NOW());
-- ============================================================
-- ARENA GAMER – schema.sql
-- AULA 1 – DDL: criação do banco e das tabelas
-- ============================================================

DROP DATABASE IF EXISTS arena_gamer;

CREATE DATABASE arena_gamer
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE arena_gamer;

-- ============================================================
-- TABELA: clientes
-- ============================================================

CREATE TABLE clientes (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    telefone VARCHAR(20),
    saldo_creditos DECIMAL(8,2) DEFAULT 0.00,
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABELA: computadores
-- ============================================================

CREATE TABLE computadores (
    id_computador INT AUTO_INCREMENT PRIMARY KEY,
    numero INT NOT NULL UNIQUE,
    descricao VARCHAR(100),
    status ENUM('disponivel','ocupado','manutencao')
        DEFAULT 'disponivel',
    valor_hora DECIMAL(6,2) NOT NULL DEFAULT 5.00
);

-- ============================================================
-- TABELA: sessoes
-- ============================================================

CREATE TABLE sessoes (
    id_sessao INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    id_computador INT NOT NULL,
    inicio DATETIME DEFAULT CURRENT_TIMESTAMP,
    fim DATETIME NULL,
    valor_total DECIMAL(8,2),
    status ENUM('aberta','fechada')
        DEFAULT 'aberta',

    CONSTRAINT fk_sessao_cliente
        FOREIGN KEY (id_cliente)
        REFERENCES clientes(id_cliente),

    CONSTRAINT fk_sessao_computador
        FOREIGN KEY (id_computador)
        REFERENCES computadores(id_computador)
);

-- ============================================================
-- TABELA: produtos
-- ============================================================

CREATE TABLE produtos (
    id_produto INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    categoria VARCHAR(50),
    preco DECIMAL(6,2) NOT NULL,
    estoque INT NOT NULL DEFAULT 0
);

-- ============================================================
-- TABELA: vendas
-- ============================================================

CREATE TABLE vendas (
    id_venda INT AUTO_INCREMENT PRIMARY KEY,
    id_sessao INT NOT NULL,
    id_produto INT NOT NULL,
    quantidade INT NOT NULL DEFAULT 1,
    preco_unitario DECIMAL(6,2) NOT NULL,
    data_venda DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_venda_sessao
        FOREIGN KEY (id_sessao)
        REFERENCES sessoes(id_sessao),

    CONSTRAINT fk_venda_produto
        FOREIGN KEY (id_produto)
        REFERENCES produtos(id_produto)
);

-- ============================================================
-- TABELA: auditoria_caixa
-- ============================================================

CREATE TABLE auditoria_caixa (
    id_auditoria INT AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('entrada','saida') NOT NULL,
    valor DECIMAL(8,2) NOT NULL,
    descricao VARCHAR(255),
    data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
    id_sessao INT NULL,

    CONSTRAINT fk_auditoria_sessao
        FOREIGN KEY (id_sessao)
        REFERENCES sessoes(id_sessao)
);

-- ============================================================
-- ÍNDICES AUXILIARES
-- ============================================================

CREATE INDEX idx_sessao_cliente
ON sessoes(id_cliente);

CREATE INDEX idx_sessao_computador
ON sessoes(id_computador);

CREATE INDEX idx_venda_sessao
ON vendas(id_sessao);

CREATE INDEX idx_venda_produto
ON vendas(id_produto);

CREATE INDEX idx_auditoria_sessao
ON auditoria_caixa(id_sessao);